<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Luxury Lo mejor en decoración para tu hogar en cortinas, persianas, piedra para interior exterior piso en Quito Ecuador</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="css/main.css" type="text/css" />
        <script type="text/javascript" src="js/libs/jquery/jquery.js"></script>
        <!-- Inicio plugin sudoSlider-->
        <script type="text/javascript" src="libs/sudo-slider/jquery.sudoSlider.js"></script>
        <link rel="stylesheet" href="libs/sudo-slider/style.css" type="text/css" />
        <!-- Fin flugin sudoSlider -->
        <!-- Inicio plugin FlowSlider-->
        <!--<script src="libs/flowslider/jquery.easing.1.3.js"></script>-->
        <script src="libs/flowslider/flowslider.jquery.js"></script>
        <!--<link rel="stylesheet" href="libs/sudo-slider/style.css" type="text/css" />-->
        <!-- Fin plugin FlowSlider-->
        
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-36348208-1', 'auto');
  ga('send', 'pageview');

</script>
        
<meta name="description" content="Luxury Home Lo mejor en decoración para tu hogar disponemos de una amplia gama de diseños exclusivos para tu comodidad." />        

<meta name="keywords" content="cortinas quito, galerias, luxury, quito, ecuador, instalacion, venta, tela,fabricamos cortinas confeccionadas, cortinas economicas, cortinas luxury, accesorios de cortina, tubo de cortina, instalación cortinas quito ecuadorcortinas, decoracion, automatización, motorización, persianas, instalacion de cortinas, alfombras, las mejores cortinas, piso flotante, cortinas en ecuador, cortinas en quito, cortinas de tela, cortinas luxury, cortinas decoraciones, cortinas luxury precios, cortinas luxury confeccion, persianas luxury, cortinas quito, cortinas para sala, cortinas moda, instalacion de cortinas, instalaciones de cortinas, bambulitas, persianas de bamboo, paneles, rieles para cortinas, visillos, galerias decoración decoracion de ventanas, diseño interiores, cortinas enrollables, cortinas decoracion, persianas luxury, puertas plegables, persianas de madera, persinas electricas, persianas de aluminio, alfombras en ecuador, alfombras precios, enrollables, visillos y cortinas, cortinas visillos, visillos para cortinas, cortinas bambu, cortinas bamboo, cortinas luxury, cortinas quito, cortinas decoracion, cortinas modernas, persianas ecuador, persinas quito, persinas verticales, persinas y cortinas, persinas y luxury, cortinas blackout, cortinas black up, cortinas screen, cortinas screens, alfombras ecuador, alfombras precios, alfombras quitoharmony, hades, triple shade, verticales, horizontales, venta. instalación, ambientes, fachadas, cielos rasos, silhouette, luminette, cebra, zebra, sebra, duo, automatizacion, tensores, sms gratis a claro, movistar, quito, ecuador. somos profesionales líderes en la venta e instalación de cortinas y persianas en ecuador, quito, guayaquil, cuenca y en todo el país.cortinas, modernas,quito, persianas, luxury, zebras, modelos, cortinas, paneles japoneses y orientales, enrollables, pisos flotantes, cortinas clasicas, cortinas de bambu y bamboo.cortinas,modernas,persianas,luxury,cebras, zebras, paneles japoneses y orientales, enrollables, pisos flotantes, cortinas clasicas, cortinas de bambu y bamboo, modelos, cortinas. estamos en quito - ecuador cortinas quito: venta y fabricación de cortinas, persianas luxury, cortinas luxury, enrrollables, zebras, cortinas verticales, horizontales, panel japones, cortinas luxury, persianas luxury, enrrollables, verticales, horizontales, bambú, panel japonés. cortinas modernas, luxury, enrrollables, zebras, triple shade, verticales, horizontales, cortinas paneladas. quito ecuador, cortinas modernas, luxury, enrrollables, zebras, paneladas, triple shade, persianas verticales, horizontales, créditos y descuentos precios de cortinas y persianas luxury pida una cotización, cortinas, decoración, persianas, instalación de cortinas,alfombras, piso flotante, cortinas en ecuador, cortinas en quito, cortinas de tela, cortinas luxury, cortinas decoraciones, cortinas luxury precios, cortinas luxury confección, persianas luxury, cortinas quito, cortinas para sala, cortinas moda, instalacion de cortinas, instalaciones de cortinas, bambulitas, persianas de bambú, paneles, rieles para cortinas, visillos, galerías decoración, decoración de ventanas, diseño de interiores, cortinas enrrollables, cortinas decoración, persianas luxury, puertas plegables, persianas de madera, persianas eléctricas, persianas de aluminio, enrrollables, visillos y cortinas, cortinas visillos, visillos para cortinas, cortinas bambú, cortinas hospitalarias, cortinas luxury, cortinas quito, cortinas decoración, cortinas modernas, persianas ecuador, persianas quito, persianas verticales, persianas y cortinas, persianas y luxury, cortinas blackout, cortinas black up, cortinas screen, cortinas screens, alfombras ecuador, alfombras precios, alfombras quito,cortinas luxury, cortinas luxury quito, cortinas luxury quito ecuador, cortinas luxury precios, cortinas luxury precios quito ecuador, venta de cortinas luxury, venta de cortinas luxury quito, venta de cortinas luxury quito ecuador, cortinas luxury en screen, cortinas luxury en blackout, cortinas luxury en traslucida, persianas luxury, persianas luxury quito, persianas luxury quito ecuador, persianas luxury precios, persianas luxury precios quito ecuador, tipos de cortinas luxury, fábrica de cortinas luxury, fábrica de cortinas luxury quito, fábrica de cortinas luxury en quito ecuador, instalación de cortinas luxury, instalación de cortinas luxury quito, instalación de cortinas luxury en quito ecuador, fábrica de cortinas, fábrica de cortinas quito fábrica de cortinas en quito ecuador, cortinas enrrollables, cortinas enrrollables quito, cortinas enrollables en quito ecuador, cortinas enrrollables precios, cortinas enrrollables precios quito, cortinas enrrollables precios quito ecuador, cortinas enrrollables blackout, cortinas enrrollables blackout quito, cortinas enrrollables en quito ecuador, cortinas enrrollables screen, cortinas enrrollables screen quito, cortinas enrrollables screen en quito ecuador, cortinas roller blackout, cortinas persianas, cortinas persianas quito, cortinas persianas quito ecuador, cortinas persianas luxury, cortinas persianas luxury quito, cortinas persianas quito ecuador, cortinas zebras, cortinas zebras quito, cortinas zebras quito ecuador, venta de cortinas zebras , venta de cortinas zebras quito, venta de cortinas zebras en quito ecuador, cortinas zebras luxury, cortinas zebras luxury quito, persianas zebras, persianas zebras quito, persianas zebras quito ecuador, cortinas enrrollables zebras, cortinas enrrollables zebras quito, cortinas enrrollables zebras en quito ecuador, persianas, persianas quito, persianas quito ecuador, persianas quito precio, persianas quito ecuador precio, persianas verticales, persianas verticales quito, persianas verticales en quito ecuador, persianas verticales pvc. persianas verticales de pvc, persianas verticales de pvc quito, persianas verticales de pvc en quito ecuador, cortinas persianas verticales, cortinas persianas verticales quito, cortinas persianas verticales en quito ecuador, fábrica de persianas verticales, venta de cortinas, venta de cortinas persianas, venta de cortinas persianas quito, venta de cortinas persianas en quito ecuador, venta de cortinas roller, venta , persianas horizontales, persianas horizontales quito, persianas horizontales en quito ecuador, persianas horizontales de aluminio, persianas horizontales de aluminio quito, persianas horizontales de aluminio en quito ecuador, venta de persianas horizontales de aluminio quito, venta de persianas horizontales de aluminio quito ecuador, venta de persianas verticales, venta de persianas verticales quito, venta de persianas verticales en quito ecuador, cortinas triple shade, cortinas triple shade quito, cortinas triple shade en quito ecuador, venta cortinas triple shade quito, venta cortinas triple shade en quito, venta cortinas triple shade en quito ecuador, cortinas paneladas, cortinas paneladas quito, cortinas paneladas en quito ecuador, venta de cortinas paneladas, venta de cortinas paneladas quito, venta de cortinas paneladas en quito ecuador, venta e instalación de cortinas, venta e instalación de cortinas quito, venta e instalación de cortinas en quito ecuador, panel japonés , panel japonés quito, panel japonés screen quito, venta de panel japonés screen quito, venta de panel japonés screen en quito ecuador, cortinas clásicas, cortinas clásicas quito, cortinas clásicas en quito ecuador, venta de cortinas clásicas, venta de cortinas clásicas quito, venta de cortinas clásicas en quito ecuador, cortinas hospitalarias, cortinas hospitalarias en quito ecuador, venta de cortinas hospitalarias en quito, venta de cortinas hospitalarias en quito ecuador, cortinas bambú, cortinas bambú quito, cortinas bambú quito ecuador, persianas bambú, persianas bambú quito, persianas bambú quito ecuador, venta de persianas bambú quito, venta de cortinas bambú quito, venta de cortinas bambú en quito ecuador, puertas plegables, puertas plegables quito, puertas plegables quito, puertas plegables en quito ecuador, divisiones plegables quito, piso flotante, piso flotante quito, alfombras quito, cortinas motorizadas, cortinas motorizadas quito, cortinas motorizadas en quito ecuador, venta de cortinas motorizadas quito, venta de cortinas motorizadas en quito ecuador, cortinas a control remoto, cortinas a control remoto quito, cortinas a control remoto en quito ecuador, venta de cortinas a control remoto, venta de cortinas a control remoto en quito, venta de cortinas a control remoto en quito ecuador, cortinas con sistema de domótica, cortinas con sistema de domótica en quito ecuador, almacén de cortinas y persianas, almacén de cortinas y persianas quito, almacén de cortinas y persianas en quito ecuador, venta de cortinas persianas, venta de cortinas y persianas quito, venta de cortinas y persianas en quito ecuador, cortinas persianas, cortinas persianas quito, cortinas persianas en quito ecuador, cortinas modernas, cortinas modernas quito, cortinas modernas en quito ecuador, venta cortinas modernas, venta cortinas modernas quito, venta cortinas modernas en quito ecuador, cortinas importadas, cortinas importadas quito, cortinas importadas en quito ecuador, rieles y tubos para cortinas, rieles y tubos para cortinas quito, rieles y tubos para cortinas en quito ecuador, visillos y cortinas, visillos y cortinas quito, visillos y cortinas en quito ecuador, local de cortinas, local de cortinas quito, local de cortinas en quito ecuador, cortinas y decoraciones, cortinas y decoraciones quito, cortinas y decoraciones en quito ecuador, cortinas cebras, cortinas cebras quito, cortinas cebras en quito ecuador, cortinas sebras, cortinas sebras quito, cortinas sebras en quito ecuador, cortinas y diseño, cortinas y diseño quito, cortinas y diseño en quito ecuador, diseñadores de cortinas,diseñadores de cortinas quito, diseñadores de cortinas en quito ecuador, diseñadores de cortinas y persianas, diseñadores de cortinas y persianas quito ecuador, diseño y decoración de cortinas, diseño y decoración de cortinas modernas en quito.cortinas quito: venta y fabricación de cortinas, persianas luxury, cortinas luxury, enrrollables, zebras, cortinas verticales, horizontales, panel japones, cortinas luxury, persianas luxury, enrrollables, verticales, horizontales, bambú, panel japonés. cortinas modernas, luxury, enrrollables, zebras, triple shade, verticales, horizontales, cortinas paneladas, quito ecuador, cortinas, modernas, luxury, enrrollables, zebras, paneladas, triple shade, persianas verticales, horizontales, créditos y descuentos del 5% al 10% precios de cortinas y persianas luxury pida una cotización, cortinas, decoración, persianas, instalación de cortinas, alfombras, piso flotante, cortinas en ecuador, cortinas en quito, cortinas de tela, cortinas luxury, cortinas decoraciones, cortinas luxury precios, cortinas luxury confección, persianas luxury, cortinas quito, cortinas para sala, cortinas moda, instalación de cortinas, instalaciones de cortinas, bambulitas, persianas de bambú, paneles, rieles para cortinas, visillos, galerías decoración, decoración de ventanas, diseño de interiores, cortinas enrrollables, cortinas decoración, persianas luxury, puertas plegables, persianas de madera, persianas eléctricas, persianas de aluminio, enrrollables, visillos y cortinas, cortinas visillos, visillos para cortinas, cortinas bambú, cortinas hospitalarias, cortinas luxury, cortinas quito, cortinas decoración, cortinas modernas, persianas ecuador, persianas quito, persianas verticales, persianas y cortinas, persianas y luxury, cortinas blackout, cortinas black up, cortinas screen, cortinas screen, quito cortinas luxury, cortinas luxury quito, cortinas luxury quito ecuador, cortinas luxury precios, cortinas luxury precios quito ecuador, venta de cortinas luxury, venta de cortinas luxury quito, venta de cortinas luxury quito ecuador, cortinas luxury en screen, cortinas luxury en blackout, cortinas luxury en traslucida, persianas luxury, persianas luxury quito, persianas luxury quito ecuador, persianas luxury precios, persianas luxury precios quito ecuador, tipos de cortinas luxury, fábrica de cortinas luxury, fábrica de cortinas luxury quito, fábrica de cortinas luxury en quito ecuador, instalación de cortinas luxury, instalación de cortinas luxury quito, instalación de cortinas luxury en quito ecuador, fábrica de cortinas, fábrica de cortinas quito fábrica de cortinas en quito ecuador, cortinas enrrollables, cortinas enrrollables quito, cortinas enrollables en quito ecuador, cortinas enrrollables precios, cortinas enrrollables precios quito, cortinas enrrollables precios quito ecuador, cortinas enrollables blackout, cortinas enrrollables blackout quito, cortinas enrrollables en quito ecuador, cortinas enrrollables screen, cortinas enrrollables screen quito, cortinas enrrollables screen en quito ecuador, cortinas roller blackout, cortinas persianas, cortinas persianas quito, cortinas persianas quito ecuador, cortinas persianas luxury, cortinas persianas luxury quito, cortinas persianas quito ecuador, cortinas zebras, cortinas zebras quito, cortinas zebras quito ecuador, venta de cortinas zebras , 
venta de cortinas zebras quito, venta de cortinas zebras en quito ecuador, cortinas zebras luxury, cortinas zebras luxury quito, persianas zebras, persianas zebras quito, persianas zebras quito ecuador, cortinas enrrollables zebras, cortinas enrrollables zebras quito, cortinas enrrollables zebras en quito ecuador, persianas, persianas quito, persianas quito ecuador, persianas quito precio, persianas quito ecuador precio, persianas verticales, persianas verticales quito, persianas verticales en quito ecuador, persianas verticales pvc. persianas verticales de pvc, persianas verticales de pvc quito, persianas verticales de pvc en quito ecuador, cortinas persianas verticales, cortinas persianas verticales quito, cortinas persianas verticales en quito ecuador, fábrica de persianas verticales, venta de cortinas, venta de cortinas persianas, venta de cortinas persianas quito, venta de cortinas persianas en quito ecuador, venta de cortinas roller, venta , persianas horizontales, persianas horizontales quito, persianas horizontales en quito ecuador, persianas horizontales de aluminio, persianas horizontales de aluminio quito, persianas horizontales de aluminio en quito ecuador, venta de persianas horizontales de aluminio quito, venta de persianas horizontales de aluminio quito ecuador, venta de persianas verticales, venta de persianas verticales quito, venta de persianas verticales en quito ecuador, cortinas triple shade, cortinas triple shade quito, cortinas triple shade en quito ecuador, venta cortinas triple shade quito, venta cortinas triple shade en quito, venta cortinas triple shade en quito ecuador, cortinas paneladas, cortinas paneladas quito, cortinas paneladas en quito ecuador, venta de cortinas paneladas, venta de cortinas paneladas quito, venta de cortinas paneladas en quito ecuador, venta e instalación de cortinas, venta e instalación de cortinas quito, venta e instalación de cortinas en quito ecuador, panel japonés , panel japonés quito, panel japonés screen quito, venta de panel japonés screen quito, venta de panel japonés screen en quito ecuador, cortinas clásicas, cortinas clásicas quito, cortinas clásicas en quito ecuador, venta de cortinas clásicas, venta de cortinas clásicas quito, venta de cortinas clásicas en quito ecuador, cortinas hospitalarias, cortinas hospitalarias en quito ecuador, venta de cortinas hospitalarias en quito, venta de cortinas hospitalarias en quito ecuador, cortinas bambú, cortinas bambú quito, cortinas bambú quito ecuador, persianas bambú, persianas bambú quito, persianas bambú quito ecuador, venta de persianas bambú quito, venta de cortinas bambú quito, venta de cortinas bambú en quito ecuador, puertas plegables, puertas plegables quito, puertas plegables quito, puertas plegables en quito ecuador, divisiones plegables quito, piso flotante, piso flotante quito, alfombras quito, cortinas motorizadas, cortinas motorizadas quito, cortinas motorizadas en quito ecuador, venta de cortinas motorizadas quito, venta de cortinas motorizadas en quito ecuador, cortinas a control remoto, cortinas a control remoto quito, cortinas a control remoto en quito ecuador, venta de cortinas a control remoto, venta de cortinas a control remoto en quito, venta de cortinas a control remoto en quito ecuador, cortinas con sistema de domótica, cortinas con sistema de domótica en quito ecuador,
 almacén de cortinas y persianas, almacén de cortinas y persianas quito, almacén de cortinas y persianas en quito ecuador, venta de cortinas persianas, venta de cortinas y persianas quito, venta de cortinas y persianas en quito ecuador, cortinas persianas, cortinas persianas quito, cortinas persianas en quito ecuador, cortinas modernas, cortinas modernas quito, cortinas modernas en cortinas zebras cortinas zebras,cortinas triple shade cortinas triple shade,cortinas paneladas cortinas paneladas,panel japones panel japones,persianas verticales persianas verticales,persianas horizontales persianas horizontales,cortinas clásicas cortinas clásicas,cortinas hospitalarias cortinas hospitalarias,cortinas bambu cortinas bambu,puertas plegables puertas plegables,piso flotante piso flotante,alfombras alfombras,automatización domótica automatización domótica,quito ecuador, venta cortinas modernas, venta cortinas modernas quito, venta cortinas modernas en quito ecuador, cortinas importadas, cortinas importadas quito, cortinas importadas en quito ecuador,rieles y tubos para cortinas, rieles y tubos para cortinas quito, rieles y tubos para cortinas en quito ecuador, visillos y cortinas, visillos y cortinas quito, visillos y cortinas en quito ecuador, local de cortinas, local de cortinas quito, local de cortinas en quito ecuador, cortinas y decoraciones, cortinas y decoraciones quito, cortinas y decoraciones en quito ecuador, cortinas cebras, cortinas cebras quito, cortinas cebras en quito ecuador, cortinas sebras, cortinas sebras quito, cortinas sebras en quito ecuador, cortinas y diseño, cortinas y diseño quito, cortinas y diseño en quito ecuador, diseñadores de cortinas,diseñadores de cortinas quito, diseñadores de cortinas en quito ecuador, diseñadores de cortinas y persianas, diseñadores de cortinas y persianas quito ecuador, diseño y decoración de cortinas, diseño y decoración de cortinas modernas en quito.cortinas luxury,cortinas enrollables cortinas enrollables, cortinas zebras cortinas zebras,cortinas triple shade cortinas triple shade, cortinas paneladas cortinas paneladas,panel japones panel japones,persianas verticales persianas verticales,persianas horizontales persianas horizontales,cortinas clásicas cortinas clásicas,cortinas hospitalarias cortinas hospitalarias, cortinas bambu cortinas bambu,puertas plegables puertas plegables,piso flotante piso flotante,alfombras cortinas quito, galerias, luxury, quito, ecuador, instalacion, venta, tela,fabricamos cortinas confeccionadas, cortinas economicas, cortinas luxury, accesorios de cortina, tubo de cortina, instalación cortinas quito ecuadorcortinas, decoracion, automatización, motorización, persianas, instalacion de cortinas, alfombras, las mejores cortinas, piso flotante, cortinas en ecuador, cortinas en quito, cortinas de tela, cortinas luxury, cortinas decoraciones, cortinas luxury precios, cortinas luxury confeccion, persianas luxury, cortinas quito, cortinas para sala, cortinas moda, instalacion de cortinas, instalaciones de cortinas, bambulitas, persianas de bamboo, paneles, rieles para cortinas, visillos, galerias decoración decoracion de ventanas, diseño interiores, cortinas enrollables, cortinas decoracion, persianas luxury, puertas plegables, persianas de madera, persinas electricas, persianas de aluminio, alfombras en ecuador, alfombras precios, enrollables, visillos y cortinas, cortinas visillos, visillos para cortinas, cortinas bambu, cortinas bamboo, cortinas luxury, cortinas quito, cortinas decoracion, cortinas modernas, persianas ecuador, persinas quito, persinas verticales, persinas y cortinas, persinas y luxury, cortinas blackout, cortinas black up, cortinas screen, cortinas screens, alfombras ecuador, alfombras precios, alfombras quitoharmony, hades, triple shade, verticales, horizontales, venta. instalación, ambientes, fachadas, cielos rasos, silhouette, luminette, cebra, zebra, sebra, duo, automatizacion, tensores, sms gratis a claro, movistar, quito, ecuador. somos profesionales líderes en la venta e instalación de cortinas y persianas en ecuador, quito, guayaquil, cuenca y en todo el país.cortinas, modernas,quito, persianas, luxury, zebras, modelos, cortinas, paneles japoneses y orientales, enrollables, pisos flotantes, cortinas clasicas, cortinas de bambu y bamboo.cortinas,modernas,persianas,luxury,cebras, zebras, paneles japoneses y orientales, enrollables, pisos flotantes, cortinas clasicas, cortinas de bambu y bamboo, modelos, cortinas. estamos en quito - ecuador cortinas quito: venta y fabricación de cortinas, persianas luxury, cortinas luxury, enrrollables, zebras, cortinas verticales, horizontales, panel japones, cortinas luxury, persianas luxury, enrrollables, verticales, horizontales, bambú, panel japonés. cortinas modernas, luxury, enrrollables, zebras,
 triple shade, verticales, horizontales, cortinas paneladas. quito ecuador, cortinas modernas, luxury, enrrollables, zebras, paneladas, triple shade, persianas verticales, horizontales, créditos y descuentos precios de cortinas y persianas luxury pida una cotización, cortinas, decoración, persianas, instalación de cortinas,alfombras, piso flotante, cortinas en ecuador, cortinas en quito, cortinas de tela, cortinas luxury, cortinas decoraciones, cortinas luxury precios, cortinas luxury confección, persianas luxury, cortinas quito, cortinas para sala, cortinas moda, instalacion de cortinas, instalaciones de cortinas, bambulitas, persianas de bambú, paneles, rieles para cortinas, visillos, galerías decoración, decoración de ventanas, diseño de interiores, cortinas enrrollables, cortinas decoración, persianas luxury, puertas plegables, persianas de madera, persianas eléctricas, persianas de aluminio, enrrollables, visillos y cortinas, cortinas visillos, visillos para cortinas, cortinas bambú, cortinas hospitalarias, cortinas luxury, cortinas quito, cortinas decoración, cortinas modernas, persianas ecuador, persianas quito, persianas verticales, persianas y cortinas, persianas y luxury, cortinas blackout, cortinas black up, cortinas screen, cortinas screens, alfombras ecuador, alfombras precios, alfombras quito,cortinas luxury, cortinas luxury quito, cortinas luxury quito ecuador, cortinas luxury precios, cortinas luxury precios quito ecuador, venta de cortinas luxury, venta de cortinas luxury quito, venta de cortinas luxury quito ecuador, cortinas luxury en screen, cortinas luxury en blackout, cortinas luxury en traslucida, persianas luxury, persianas luxury quito, persianas luxury quito ecuador, persianas luxury precios, persianas luxury precios quito ecuador, tipos de cortinas luxury, fábrica de cortinas luxury, fábrica de cortinas luxury quito, fábrica de cortinas luxury en quito ecuador, instalación de cortinas luxury, instalación de cortinas luxury quito, instalación de cortinas luxury en quito ecuador, fábrica de cortinas, fábrica de cortinas quito fábrica de cortinas en quito ecuador, cortinas enrrollables, cortinas enrrollables quito, cortinas enrollables en quito ecuador, cortinas enrrollables precios, cortinas enrrollables precios quito, cortinas enrrollables precios quito ecuador, cortinas enrrollables blackout, cortinas enrrollables blackout quito, cortinas enrrollables en quito ecuador, cortinas enrrollables screen, cortinas enrrollables screen quito, cortinas enrrollables screen en quito ecuador, cortinas roller blackout, cortinas persianas, cortinas persianas quito, cortinas persianas quito ecuador, cortinas persianas luxury, cortinas persianas luxury quito, cortinas persianas quito ecuador, cortinas zebras, cortinas zebras quito, cortinas zebras quito ecuador, venta de cortinas zebras , venta de cortinas zebras quito, venta de cortinas zebras en quito ecuador, cortinas zebras luxury, cortinas zebras luxury quito, persianas zebras, persianas zebras quito, persianas zebras quito ecuador, cortinas enrrollables zebras, cortinas enrrollables zebras quito, cortinas enrrollables zebras en quito ecuador, persianas, persianas quito, persianas quito ecuador, persianas quito precio, persianas quito ecuador precio, persianas verticales, persianas verticales quito, persianas verticales en quito ecuador, persianas verticales pvc. persianas verticales de pvc, persianas verticales de pvc quito, persianas verticales de pvc en quito ecuador, cortinas persianas verticales, cortinas persianas verticales quito, cortinas persianas verticales en quito ecuador, fábrica de persianas verticales, venta de cortinas, venta de cortinas persianas, venta de cortinas persianas quito, venta de cortinas persianas en quito ecuador, venta de cortinas roller, venta , persianas horizontales, persianas horizontales quito, persianas horizontales en quito ecuador, persianas horizontales de aluminio, persianas horizontales de aluminio quito, persianas horizontales de aluminio en quito ecuador, venta de persianas horizontales de aluminio quito, venta de persianas horizontales de aluminio quito ecuador, venta de persianas verticales, venta de persianas verticales quito, venta de persianas verticales en quito ecuador, cortinas triple shade, cortinas triple shade quito, cortinas triple shade en quito ecuador, venta cortinas triple shade quito, venta cortinas triple shade en quito, venta cortinas triple shade en quito ecuador, cortinas paneladas, cortinas paneladas quito, cortinas paneladas en quito ecuador, venta de cortinas paneladas, venta de cortinas paneladas quito, venta de cortinas paneladas en quito ecuador, venta e instalación de cortinas, venta e instalación de cortinas quito, venta e instalación de cortinas en quito ecuador, panel japonés , panel japonés quito, panel japonés screen quito, venta de panel japonés screen quito, venta de panel japonés screen en quito ecuador, cortinas clásicas, cortinas clásicas quito, cortinas clásicas en quito ecuador, venta de cortinas clásicas, venta de cortinas clásicas quito, venta de cortinas clásicas en quito ecuador, cortinas hospitalarias, cortinas hospitalarias en quito ecuador, venta de cortinas hospitalarias en quito, venta de cortinas hospitalarias en quito ecuador, cortinas bambú, cortinas bambú quito, cortinas bambú quito ecuador, persianas bambú, persianas bambú quito, persianas bambú quito ecuador, venta de persianas bambú quito, venta de cortinas bambú quito, venta de cortinas bambú en quito ecuador, puertas plegables, puertas plegables quito, puertas plegables quito, puertas plegables en quito ecuador, divisiones plegables quito, piso flotante, piso flotante quito, alfombras quito, cortinas motorizadas, cortinas motorizadas quito, cortinas motorizadas en quito ecuador, venta de cortinas motorizadas quito, venta de cortinas motorizadas en quito ecuador, cortinas a control remoto, cortinas a control remoto quito, cortinas a control remoto en quito ecuador, venta de cortinas a control remoto, venta de cortinas a control remoto en quito, venta de cortinas a control remoto en quito ecuador, cortinas con sistema de domótica, cortinas con sistema de domótica en quito ecuador, almacén de cortinas y persianas, almacén de cortinas y persianas quito, almacén de cortinas y persianas en quito ecuador, venta de cortinas persianas, venta de cortinas y persianas quito, venta de cortinas y persianas en quito ecuador, cortinas persianas, cortinas persianas quito, cortinas persianas en quito ecuador, cortinas modernas, cortinas modernas quito, cortinas modernas en quito ecuador, venta cortinas modernas, venta cortinas modernas quito, venta cortinas modernas en quito ecuador, cortinas importadas, cortinas importadas quito, cortinas importadas en quito ecuador, rieles y tubos para cortinas, rieles y tubos para cortinas quito, rieles y tubos para cortinas en quito ecuador, visillos y cortinas, visillos y cortinas quito, visillos y cortinas en quito ecuador, local de cortinas, local de cortinas quito, local de cortinas en quito ecuador, cortinas y decoraciones, cortinas y decoraciones quito, cortinas y decoraciones en quito ecuador, cortinas cebras, cortinas cebras quito, cortinas cebras en quito ecuador, cortinas sebras, cortinas sebras quito, cortinas sebras en quito ecuador, cortinas y diseño, cortinas y diseño quito, cortinas y diseño en quito ecuador, diseñadores de cortinas,diseñadores de cortinas quito, diseñadores de cortinas en quito ecuador, diseñadores de cortinas y persianas, diseñadores de cortinas y persianas quito ecuador, diseño y decoración de cortinas, diseño y decoración de cortinas modernas en quito.cortinas quito: venta y fabricación de cortinas, persianas luxury, cortinas luxury, enrrollables, zebras, cortinas verticales, horizontales, panel japones, cortinas luxury, persianas luxury, enrrollables, verticales, horizontales, bambú, panel japonés. cortinas modernas, luxury, enrrollables, zebras, triple shade, verticales, horizontales, cortinas paneladas, quito ecuador, cortinas, modernas, luxury, enrrollables, zebras, paneladas, triple shade, persianas verticales, horizontales, créditos y descuentos del 5% al 10% precios de cortinas y persianas luxury pida una cotización, cortinas, decoración, persianas, instalación de cortinas, alfombras, piso flotante, cortinas en ecuador, cortinas en quito, cortinas de tela, cortinas luxury, cortinas decoraciones, cortinas luxury precios, cortinas luxury confección, persianas luxury, cortinas quito, cortinas para sala, cortinas moda, instalación de cortinas, instalaciones de cortinas, bambulitas, persianas de bambú, paneles, rieles para cortinas, visillos, galerías decoración, decoración de ventanas, diseño de interiores, cortinas enrrollables, cortinas decoración, persianas luxury, puertas plegables, persianas de madera, persianas eléctricas, persianas de aluminio, enrrollables, visillos y cortinas, cortinas visillos, visillos para cortinas, cortinas bambú, cortinas hospitalarias, cortinas luxury, cortinas quito, cortinas decoración, cortinas modernas, persianas ecuador, persianas quito, persianas verticales, persianas y cortinas, persianas y luxury, cortinas blackout, cortinas black up, cortinas screen, cortinas screen, quito cortinas luxury, cortinas luxury quito, cortinas luxury quito ecuador, cortinas luxury precios, cortinas luxury precios quito ecuador, venta de cortinas luxury, venta de cortinas luxury quito, venta de cortinas luxury quito ecuador, cortinas luxury en screen, cortinas luxury en blackout, cortinas luxury en traslucida, persianas luxury, persianas luxury quito, persianas luxury quito ecuador, persianas luxury precios, persianas luxury precios quito ecuador, tipos de cortinas luxury, fábrica de cortinas luxury, fábrica de cortinas luxury quito, fábrica de cortinas luxury en quito ecuador, instalación de cortinas luxury, instalación de cortinas luxury quito, instalación de cortinas luxury en quito ecuador, fábrica de cortinas, fábrica de cortinas quito fábrica de cortinas en quito ecuador, cortinas enrrollables, cortinas enrrollables quito, cortinas enrollables en quito ecuador, cortinas enrrollables precios, cortinas enrrollables precios quito, cortinas enrrollables precios quito ecuador, cortinas enrollables blackout, cortinas enrrollables blackout quito, cortinas enrrollables en quito ecuador, cortinas enrrollables screen, cortinas enrrollables screen quito, cortinas enrrollables screen en quito ecuador, cortinas roller blackout, cortinas persianas, cortinas persianas quito, cortinas persianas quito ecuador, cortinas persianas luxury, cortinas persianas luxury quito, cortinas persianas quito ecuador, cortinas zebras, cortinas zebras quito, cortinas zebras quito ecuador, venta de cortinas zebras , venta de cortinas zebras quito, venta de cortinas zebras en quito ecuador, cortinas zebras luxury, cortinas zebras luxury quito, persianas zebras, persianas zebras quito, persianas zebras quito ecuador, cortinas enrrollables zebras, cortinas enrrollables zebras quito, cortinas enrrollables zebras en quito ecuador, persianas, persianas quito, persianas quito ecuador, persianas quito precio, persianas quito ecuador precio, persianas verticales, persianas verticales quito, persianas verticales en quito ecuador, persianas verticales pvc. persianas verticales de pvc, persianas verticales de pvc quito, persianas verticales de pvc en quito ecuador, cortinas persianas verticales, cortinas persianas verticales quito, cortinas persianas verticales en quito ecuador, fábrica de persianas verticales, venta de cortinas, venta de cortinas persianas, venta de cortinas persianas quito, venta de cortinas persianas en quito ecuador, venta de cortinas roller, venta , persianas horizontales, persianas horizontales quito, persianas horizontales en quito ecuador, persianas horizontales de aluminio, persianas horizontales de aluminio quito, persianas horizontales de aluminio en quito ecuador, venta de persianas horizontales de aluminio quito, venta de persianas horizontales de aluminio quito ecuador, venta de persianas verticales, venta de persianas verticales quito, venta de persianas verticales en quito ecuador, cortinas triple shade, cortinas triple shade quito, cortinas triple shade en quito ecuador, venta cortinas triple shade quito, venta cortinas triple shade en quito, venta cortinas triple shade en quito ecuador, cortinas paneladas, cortinas paneladas quito, cortinas paneladas en quito ecuador, venta de cortinas paneladas, venta de cortinas paneladas quito, venta de cortinas paneladas en quito ecuador, venta e instalación de cortinas, venta e instalación de cortinas quito, venta e instalación de cortinas en quito ecuador, panel japonés , panel japonés quito, panel japonés screen quito, venta de panel japonés screen quito, venta de panel japonés screen en quito ecuador, cortinas clásicas, cortinas clásicas quito, cortinas clásicas en quito ecuador, venta de cortinas clásicas, venta de cortinas clásicas quito, venta de cortinas clásicas en quito ecuador, cortinas hospitalarias, cortinas hospitalarias en quito ecuador, venta de cortinas hospitalarias en quito, venta de cortinas hospitalarias en quito ecuador, cortinas bambú, cortinas bambú quito, cortinas bambú quito ecuador, persianas bambú, persianas bambú quito, persianas bambú quito ecuador, venta de persianas bambú quito, venta de cortinas bambú quito, venta de cortinas bambú en quito ecuador, puertas plegables, puertas plegables quito, puertas plegables quito, puertas plegables en quito ecuador, divisiones plegables quito, piso flotante, piso flotante quito, alfombras quito, cortinas motorizadas, cortinas motorizadas quito, cortinas motorizadas en quito ecuador, venta de cortinas motorizadas quito, venta de cortinas motorizadas en quito ecuador, cortinas a control remoto, cortinas a control remoto quito, cortinas a control remoto en quito ecuador, venta de cortinas a control remoto, venta de cortinas a control remoto en quito, venta de cortinas a control remoto en quito ecuador, cortinas con sistema de domótica, cortinas con sistema de domótica en quito ecuador, almacén de cortinas y persianas, almacén de cortinas y persianas quito, almacén de cortinas y persianas en quito ecuador, venta de cortinas persianas, venta de cortinas y persianas quito, venta de cortinas y persianas en quito ecuador, cortinas persianas, cortinas persianas quito, cortinas persianas en quito ecuador, cortinas modernas, cortinas modernas quito, cortinas modernas en cortinas zebras cortinas zebras,cortinas triple shade cortinas triple shade,cortinas paneladas cortinas paneladas,panel japones panel japones,persianas verticales persianas verticales,persianas horizontales persianas horizontales,cortinas clásicas cortinas clásicas,cortinas hospitalarias cortinas hospitalarias,cortinas bambu cortinas bambu,puertas plegables puertas plegables,piso flotante piso flotante,alfombras alfombras,automatización domótica automatización domótica,quito ecuador, venta cortinas modernas, venta cortinas modernas quito, venta cortinas modernas en quito ecuador, cortinas importadas, cortinas importadas quito, cortinas importadas en quito ecuador,rieles y tubos para cortinas, rieles y tubos para cortinas quito, rieles y tubos para cortinas en quito ecuador, visillos y cortinas, visillos y cortinas quito, visillos y cortinas en quito ecuador, local de cortinas, local de cortinas quito, local de cortinas en quito ecuador, cortinas y decoraciones, cortinas y decoraciones quito, cortinas y decoraciones en quito ecuador, cortinas cebras, cortinas cebras quito, cortinas cebras en quito ecuador, cortinas sebras, cortinas sebras quito, cortinas sebras en quito ecuador, cortinas y diseño, cortinas y diseño quito, cortinas y diseño en quito ecuador, diseñadores de cortinas,diseñadores de cortinas quito, diseñadores de cortinas en quito ecuador, diseñadores de cortinas y persianas, diseñadores de cortinas y persianas quito ecuador, diseño y decoración de cortinas, diseño y decoración de cortinas modernas en quito.cortinas luxury,cortinas enrollables cortinas enrollables, cortinas zebras cortinas zebras,cortinas triple shade cortinas triple shade, cortinas paneladas cortinas paneladas,panel japones panel japones,persianas verticales persianas verticales,persianas horizontales persianas horizontales,cortinas clásicas cortinas clásicas,cortinas hospitalarias cortinas hospitalarias, cortinas bambu cortinas bambu,puertas plegables puertas plegables,piso flotante piso flotante,alfombras" />        
        
        <script>
                    $(document).ready(function(){	
                        var sudoSlider = $("#slider1").sudoSlider({
                           auto:true,
                           effect:'fade',
                           prevNext:false
                        });
                      
                    });
       </script>
        <script>
            jQuery(document).ready(function($) {
                $("#content_productos_generic").FlowSlider();
            });
        </script>
        
        <!--  javaScript -->
        <script>  
        <!--  // building select nav for mobile width only -->


        // show and hide sub menu
        $(function(){
                $('nav ul li').hover(
                        function () {
                                //show its submenu
                                $('ul', this).slideDown(150);
                        }, 
                        function () {
                                //hide its submenu
                                $('ul', this).slideUp(150);			
                        }
                );
        });
        //end
        </script>
        <!-- end -->           
   
        
<!-- Inicio plugin Twitter -->
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<!-- Fin plugin Twitter -->

    </head>
    <body>

        
<!--Inicio plugin Facebook -->        
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- Fin plugin Facebook -->


        <div id="content_principal">
            <header>
                <div id="logotipo">
                    <img src="img/logo_luxury.png" />
                </div>
                    <nav>
                        <ul>
                            <li><a href="index.php">Inicio</a>
                            </li>
                            <li class="current">
                                    <a href="productos.php">Productos</a>
                                    <ul style="display: none;" class="sub_menu">
                                            <li><a href="stone.php">Stone </a></li>
                                            <li class="current"><a href="blinds.php">Blinds </a></li>
                                    </ul>
                            </li>
                            <li>
                                    <a href="luxury.html">Luxury</a>
                            </li>
                            <li>
                                    <a href="videos.php">Videos</a>
                            </li>
                            <li><a href="contactos.html">Contactos</a></li>
                        </ul>
                    </nav>
            </header>
            <div id="content_second_generic">
                <div id="content_productos_total">
                <div class="producto_etiqueta_generic">
                    Blinds
                </div>                
                <div id="content_productos_generic">
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_zebra">
                              
                                
                                
                        <?php
                            
                            $directorio = opendir('viewer/cortinas_zebra/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_zebra/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>                                  
                                
                                
                                
                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_zebra">Zebras</a>
                        </div>                                
                    </div>
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_romana">

                                
                                
                        <?php
                            
                            $directorio = opendir('viewer/cortinas_romana/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_romana/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>                                  
                                
                                
                                
                                
                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_romana">Romana</a>
                        </div>                                
                    </div>
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_sirffio">
                                
                        <?php
                            
                            $directorio = opendir('viewer/cortinas_sirffio/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_sirffio/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>                              
                            
                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_sirffio">Sirffio</a>
                        </div>                                
                    </div>
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_soft-sheer">

                                
                                
                                
                                
                        <?php
                            
                            $directorio = opendir('viewer/cortinas_soft-sheer/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_soft-sheer/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>                                  
                            
                            
                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_soft-sheer">Soft-Sheer</a>
                        </div>                                
                    </div>
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_roller">




                        <?php
                            
                            $directorio = opendir('viewer/cortinas_roller/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_roller/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>  







                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_roller">Roller</a>
                        </div>                                
                    </div>
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_lohas">



                        <?php
                            
                            $directorio = opendir('viewer/cortinas_lohas/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_lohas/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>  


                                
                                
                                
                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_lohas">Lohas</a>
                        </div>                                
                    </div>
                    <div class="producto_generic">
                        <div class="subproducto_imagen">
                            <a href="viewer.php?productos=viewer/cortinas_paneladas">
                                
                                
                                
                                
                        <?php
                            
                            $directorio = opendir('viewer/cortinas_paneladas/portada'); //ruta actual
                            while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                            {
                                if (!is_dir($archivo))//verificamos si es o no un directorio
                                {
                                    $partes_archivo=explode('.',$archivo);
                                    $extension=end($partes_archivo);
                                    if(strtolower($extension)=='jpg' || strtolower($extension)=='png'){
                       ?>

                                                <img src="<?php echo 'viewer/cortinas_paneladas/portada/'.$archivo ?>" alt="Luxury persianas, cortinas y piedra para piso" />

                
                        <?php
                                    }
                                }
                            }
                        ?>  
                            
                            
                            </a>
                        </div>
                        <div class="subproducto_etiqueta">
                            <a href="viewer.php?productos=viewer/cortinas_paneladas">Paneladas</a>
                        </div>                                
                    </div>                    
                </div>
                </div>
                <div id="paneles">
                    <div id="panel_i">
                        <div class="fb-comments" data-href="http://www.luxury.ec" data-numposts="5" data-width="350" data-colorscheme="dark"></div>
                    </div>
                    <div id="panel_d">
                        <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/luxury_ec" data-widget-id="556456560831246336">Tweets por el @luxury_ec.</a>
                    </div>
                </div>
            </div>

        </div>
            <footer>
                <img src="img/barras.png" style="float:left; margin-right: 20px; margin-top:-104px;"/>
                <div id="barra_footer">
                    <div class="columnas">
                        <div class="ciudad">
                            Quito
                        </div>
                        Coruña y Toledo Esq.<br/>
                        02 252 0702 / 02 254 2351 / 02 255 2724 / 02 223 8899
                    </div>
                    <div class="columnas">

                    </div>
                    <div class="columnas">
                        <div class="ciudad">
                            Teléfono Directo
                        </div>
                        <span>1800 - LUXURY</span><br/>

                    </div>                    
                </div>
                <div id="redes">
                    <a href="https://www.facebook.com/www.luxury.ec?fref=ts"><div class="item_redes fb">
                    </div></a>
                    <a href="https://twitter.com/luxury_ec"><div class="item_redes yt">
                    </div></a>
                    <a href="https://www.youtube.com/user/LuxuryEc"><div class="item_redes tw">
                    </div></a>
                </div>    

                
                
            </footer>           
    </body>
</html>
